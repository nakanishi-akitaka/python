#!/usr/bin/env python
# -*- coding: utf-8 -*-

import math
from pymatgen import Element
fe=Element("Fe")
print(fe.data)
print(fe.ionic_radii)
